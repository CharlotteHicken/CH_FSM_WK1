﻿namespace NodeCanvas.Framework
{
    ///<summary>This is a very special dummy class for variable header separators</summary>
    public class VariableSeperator
    {
        public VariableSeperator() { }
        public bool isEditingName { get; set; }
    }
}